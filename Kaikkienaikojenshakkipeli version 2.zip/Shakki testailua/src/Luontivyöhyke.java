
public class Luontivy�hyke {
	int randomshit;
	public Luontivy�hyke(int juttu) {
		this.randomshit = juttu;
	}
	public Sotilas MS1 = new Sotilas(1, 1, 1, 1);
	

}
