import java.util.ArrayList;
public class Nappula {
	public int sijaintiX;
	public int sijaintiY;
	public int vari;
	public int elossa = 0;
	public int SSM;  //sijainti sy�nti metodille //ei k�yt�ss�
	String nimi;
	// nimet��n esim n�in Ensin v�ri M tai V sitten nappula Esim sotilas S sitten numero esim. MS1
	public Nappula(int SijaintiX, int SijaintiY, int vari, int elossa) {
		this.sijaintiX = SijaintiX;
		this.sijaintiY = SijaintiY;
		this.vari = vari;
		this.nimi = nimi;
	}
	public void asetaSijainti(int x, int y) {
		this.sijaintiX = x;
		this.sijaintiY = y;
	}
	public int annaSijaintiX() {
		return this.sijaintiX;
	}
	public int  annaSijaintiY() {
		return this.sijaintiY;
	}
	public void Elossa(){
		this.elossa = 0; // 0 eli on elossa 1 eli kuollut
	}
	public int annaVari() {
		return this.vari;
	}
	public void tapa() {
		this.elossa = 1;
	}
}
