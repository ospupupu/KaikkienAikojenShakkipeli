public class Sotilas extends Nappula {
	public Sotilas(int SijaintiX, int SijaintiY, int vari, int elossa, String nimi) {
		super(SijaintiX, SijaintiY, vari, elossa);
		this.nimi = nimi;
	}
	public boolean Onkosiirtosallittu(int x, int y) {
		boolean a = true;
		boolean b = false;
		if ( elossa == 0) {
			if (x == this.sijaintiX && y == this.sijaintiY +1 && y > 0 && y <= 8 && x > 0 && x <= 8)  {
					return a;
			}
			else {
				return b;
			}
		}
		else{
			return b;
		}
	}
	public void siirraSotilas(int x, int y){
		asetaSijainti(x, y);
	}
	public String nimi() {
		return nimi;
	}
}	


