import java.util.Random;
import java.util.ArrayList;

public class Test{
    public static void main(String[] args){
        final Random r = new Random();
        
        
        ArrayList<Vanhempi> ihmiset = new ArrayList<Vanhempi>();
        for(int i = 0; i < 20; i++){
            int tyyppi = r.nextInt(3);
            switch(tyyppi){
                case 0:
                    ihmiset.add(new Vanhempi(r.nextInt(40) + 10));
                    break;
                case 1:
                    ihmiset.add(new Isovanhempi(r.nextInt(40) + 10,r.nextInt(40) + 500));
                    break;
                case 2:
                    ihmiset.add(new Isoisovanhempi(r.nextInt(40) + 10,r.nextInt(40) + 500,r.nextInt(40) + 1000));
                    break;
            }
        }
        
        System.out.println("Ihmiset:\n" + ihmiset+"\n");
        
        System.out.println("Lapset yhteens�: " + vanhempienLapset(ihmiset));
        
    }
    
    
    public static int vanhempienLapset(ArrayList<Vanhempi> ihmiset){
        for( int i = 0; i < 6; i++){
            return i;
    }
    
    
    
    
    
    
    
}

class Vanhempi{
    
    private int lapset;
    
    public Vanhempi(int lapset){
        this.lapset = lapset;
    }
    
    public void asetaHenkilosto(int lapset){
        this.lapset = lapset;
    }
    
    public int annaLapset(){
        return lapset;
    }
    
    public String toString(){
        return "Vanhemman lapset (" + lapset + ")";
    }
    
}

class Isovanhempi extends Vanhempi{
    
    private int lapsenlapset;
    
    public Isovanhempi(int henkilosto, int lapsenlapset){
        super(henkilosto);
        this.lapsenlapset = lapsenlapset;
    }
    
    public void asetaMatkustajat(int lapsenlapset){
        this.lapsenlapset = lapsenlapset;
    }
    
    public int annaLapsenlapset(){
        return this.lapsenlapset;
    }
    
    public String toString(){
        return "Isovanhemman lapset (" + (super.annaLapset() + lapsenlapset) + ")";
    }
}

class Isoisovanhempi extends Isovanhempi{
    
    private int lapsenlapsenlapset;
    
    public Isoisovanhempi(int lapset, int lapsenlapset, int lapsenlapsenlapset){
        super(lapset,lapsenlapset);
        this.lapsenlapsenlapset = lapsenlapsenlapset;
    }
    
    public void asetaLapsenlapset(int lapsenlapsenlapset){
        this.lapsenlapsenlapset = lapsenlapsenlapset;
    }
    
    public int annaLapsenlapsenlapset(){
        return this.lapsenlapsenlapset;
    }
    
    public String toString(){
        return "Isoisovanhemman lapset (" + (super.annaLapset() + super.annaLapsenlapset() + lapsenlapsenlapset) + ")";
    }
}




