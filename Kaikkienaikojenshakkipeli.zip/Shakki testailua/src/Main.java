import java.util.ArrayList;
import java.util.Scanner;
public class Main {
  public static void main(String[] args)
  {
	  ArrayList<Nappula> pelilauta = new ArrayList<Nappula>();
	  for(int i = 0; i<8*100; i++) {
			pelilauta.add(i, null);
		}
	    String ms1 = "MS1";
	    String ms2 = "MS2";
		String ms3 = "MS3";
		String ms4 = "MS4";
		String ms5 = "MS5";
		String ms6 = "MS6";
		String ms7 = "MS7";
		String ms8 = "MS8";
		
		String mt1 = "MT1";
		String mt2 = "MT2";
		
		String mh1 = "MH1";
		String mh2 = "MH2";
		
		String ml1 = "ML1";
		String ml2 = "ML2";
		
		String mk = "MK";
		String mq = "MQ";
		
		String vs1 = "VS1";
	    String vs2 = "VS2";
		String vs3 = "VS3";
		String vs4 = "VS4";
		String vs5 = "VS5";
		String vs6 = "VS6";
		String vs7 = "VS7";
		String vs8 = "VS8";
		
		String vt1 = "VT1";
		String vt2 = "VT2";
		
		String vh1 = "VH1";
		String vh2 = "VH2";
		
		String vl1 = "VL1";
		String vl2 = "VL2";
		
		String vk = "VK";
		String vq = "VQ";
	  	
	    Sotilas MS1 = new Sotilas(1, 2, 0, 1, ms1);
		Sotilas MS2 = new Sotilas(2, 2, 0, 1, ms2);
		Sotilas MS3 = new Sotilas(3, 2, 0, 1, ms3);
		Sotilas MS4 = new Sotilas(4, 2, 0, 1, ms4);
		Sotilas MS5 = new Sotilas(5, 2, 0, 1, ms5);
		Sotilas MS6 = new Sotilas(6, 2, 0, 1, ms6);
		Sotilas MS7 = new Sotilas(7, 2, 0, 1, ms7);
		Sotilas MS8 = new Sotilas(8, 2, 0, 1, ms8);
		
		Torni MT1 = new Torni(1, 1, 0, 1);
		Torni MT2 = new Torni(8, 1, 0, 1);
		
		Hevonen MH1 = new Hevonen(2, 1, 0, 1);
		Hevonen MH2 = new Hevonen(7, 1, 0, 1);
		
		pelilauta.set(11, MT1);
		pelilauta.set(81, MT2);
		
		pelilauta.set(12, MS1);
		pelilauta.set(22, MS2);
		pelilauta.set(32, MS3);
		pelilauta.set(42, MS4);
		pelilauta.set(52, MS5);
		pelilauta.set(62, MS6);
		pelilauta.set(72, MS7);
		pelilauta.set(82, MS8);
		
		pelilauta.set(21, MH1);
		pelilauta.set(71, MH2);
		
		Lahetti ML1 = new Lahetti(3, 1, 0, 1);
		Lahetti ML2 = new Lahetti(6, 1, 0, 1);
		pelilauta.set(31, ML1);
		pelilauta.set(61, ML2);
		
		Kuningas MK = new Kuningas(4, 1, 0, 1);
		pelilauta.set(41, MK);
		
		Kuningatar MQ = new Kuningatar(5, 1, 0, 1);
		pelilauta.set(51, MQ);

		Sotilas VS1 = new Sotilas(1, 7, 1, 1, ms1);
		Sotilas VS2 = new Sotilas(2, 7, 1, 1, ms2);
		Sotilas VS3 = new Sotilas(3, 7, 1, 1, ms3);
		Sotilas VS4 = new Sotilas(4, 7, 1, 1, ms4);
		Sotilas VS5 = new Sotilas(5, 7, 1, 1, ms5);
		Sotilas VS6 = new Sotilas(6, 7, 1, 1, ms6);
		Sotilas VS7 = new Sotilas(7, 7, 1, 1, ms7);
		Sotilas VS8 = new Sotilas(8, 7, 1, 1, ms8);
		
		pelilauta.set(17, VS1);
		pelilauta.set(27, VS2);
		pelilauta.set(37, VS3);
		pelilauta.set(47, VS4);
		pelilauta.set(57, VS5);
		pelilauta.set(67, VS6);
		pelilauta.set(77, VS7);
		pelilauta.set(87, VS8);
		
		Hevonen VH1 = new Hevonen(2, 8, 1, 0);
		Hevonen VH2 = new Hevonen(7, 8, 1, 0);
		pelilauta.set(28, VH1);
		pelilauta.set(78, VH2);
		
		Lahetti VL1 = new Lahetti(3, 8, 1, 0);
		Lahetti VL2 = new Lahetti(6, 8, 1, 0);
		pelilauta.set(38, VL1);
		pelilauta.set(68, VL2);
		
		Torni VT1 = new Torni(1, 8, 1, 0);
		Torni VT2 = new Torni(8, 8, 1, 0);
		pelilauta.set(18, VT1);
		pelilauta.set(88, VT2);
		
		Kuningas VK = new Kuningas(5, 8, 1, 0);
		pelilauta.set(58, VK);
		
		Kuningatar VQ = new Kuningatar(4, 8, 1, 0);
		pelilauta.set(48, VQ);
	  for (int i = 0; i < 88888; i++) {
		Scanner input = new Scanner (System.in);
	    System.out.print("Valitse nappula: ");
	    String nappula = input.next();
	    System.out.print("Anna x koordinaatti? ");
	    String sijaintix = input.next();
	    System.out.print("Anna y koordinaatti? ");
	    String sijaintiy = input.next();
	    if (nappula.equals(ms2)) {
	    	int tulosx1 = Integer.parseInt(sijaintix);
	    	int tulosy1 = Integer.parseInt(sijaintiy);
	    	if (MS2.Onkosiirtosallittu(tulosx1, tulosy1)) {
	    		int sijainti = 10 * tulosx1 + tulosy1;
	    		int vanhasijainti = 10 * MS2.annaSijaintiX() + MS2.annaSijaintiY();
	    		if (pelilauta.get(sijainti) == null) {
	    			pelilauta.set(vanhasijainti, null);
	    			pelilauta.set(sijainti, MS2);
	    			MS2.asetaSijainti(tulosx1, tulosy1);
	    		}
	    		else {
		    		pelilauta.set(vanhasijainti, null);
		    		pelilauta.set(sijainti, MS2);
		    		MS2.asetaSijainti(tulosx1, tulosy1);
	    		}
	    	}
	    }
	    if (nappula.equals(ms1)) {
	    	int tulosx1 = Integer.parseInt(sijaintix);
	    	int tulosy1 = Integer.parseInt(sijaintiy);
	    	if (MS1.Onkosiirtosallittu(tulosx1, tulosy1)) {
	    		int sijainti = 10 * tulosx1 + tulosy1;
	    		int vanhasijainti = 10 * MS1.annaSijaintiX() + MS1.annaSijaintiY();
	    		if (pelilauta.get(sijainti) == null) {
	    			pelilauta.set(vanhasijainti, null);
	    			pelilauta.set(sijainti, MS1);
	    			MS1.asetaSijainti(tulosx1, tulosy1);
	    		}
	    		else {
		    		pelilauta.set(vanhasijainti, null);
		    		pelilauta.set(sijainti, MS1);
		    		MS1.asetaSijainti(tulosx1, tulosy1);
	    		}
	    	}
	    }
	    if (nappula.equals(ms3)) {
	    	int tulosx1 = Integer.parseInt(sijaintix);
	    	int tulosy1 = Integer.parseInt(sijaintiy);
	    	if (MS3.Onkosiirtosallittu(tulosx1, tulosy1)) {
	    		int sijainti = 10 * tulosx1 + tulosy1;
	    		int vanhasijainti = 10 * MS3.annaSijaintiX() + MS3.annaSijaintiY();
	    		if (pelilauta.get(sijainti) == null) {
	    			pelilauta.set(vanhasijainti, null);
	    			pelilauta.set(sijainti, MS3);
	    			MS3.asetaSijainti(tulosx1, tulosy1);
	    		}
	    		else {
		    		pelilauta.set(vanhasijainti, null);
		    		pelilauta.set(sijainti, MS3);
		    		MS3.asetaSijainti(tulosx1, tulosy1);
	    		}
	    	}
	    }
	    if (nappula.equals(ms4)) {
	    	int tulosx1 = Integer.parseInt(sijaintix);
	    	int tulosy1 = Integer.parseInt(sijaintiy);
	    	if (MS4.Onkosiirtosallittu(tulosx1, tulosy1)) {
	    		int sijainti = 10 * tulosx1 + tulosy1;
	    		int vanhasijainti = 10 * MS4.annaSijaintiX() + MS4.annaSijaintiY();
	    		if (pelilauta.get(sijainti) == null) {
	    			pelilauta.set(vanhasijainti, null);
	    			pelilauta.set(sijainti, MS4);
	    			MS4.asetaSijainti(tulosx1, tulosy1);
	    		}
	    		else {
		    		pelilauta.set(vanhasijainti, null);
		    		pelilauta.set(sijainti, MS4);
		    		MS4.asetaSijainti(tulosx1, tulosy1);
	    		}
	    	}
	    }
	    if (nappula.equals(ms5)) {
	    	int tulosx1 = Integer.parseInt(sijaintix);
	    	int tulosy1 = Integer.parseInt(sijaintiy);
	    	if (MS5.Onkosiirtosallittu(tulosx1, tulosy1)) {
	    		int sijainti = 10 * tulosx1 + tulosy1;
	    		int vanhasijainti = 10 * MS5.annaSijaintiX() + MS5.annaSijaintiY();
	    		if (pelilauta.get(sijainti) == null) {
	    			pelilauta.set(vanhasijainti, null);
	    			pelilauta.set(sijainti, MS5);
	    			MS5.asetaSijainti(tulosx1, tulosy1);
	    		}
	    		else {
		    		pelilauta.set(vanhasijainti, null);
		    		pelilauta.set(sijainti, MS5);
		    		MS5.asetaSijainti(tulosx1, tulosy1);
	    		}
	    	}
	    }
	    if (nappula.equals(ms6)) {
	    	int tulosx1 = Integer.parseInt(sijaintix);
	    	int tulosy1 = Integer.parseInt(sijaintiy);
	    	if (MS6.Onkosiirtosallittu(tulosx1, tulosy1)) {
	    		int sijainti = 10 * tulosx1 + tulosy1;
	    		int vanhasijainti = 10 * MS6.annaSijaintiX() + MS6.annaSijaintiY();
	    		if (pelilauta.get(sijainti) == null) {
	    			pelilauta.set(vanhasijainti, null);
	    			pelilauta.set(sijainti, MS6);
	    			MS6.asetaSijainti(tulosx1, tulosy1);
	    		}
	    		else {
		    		pelilauta.set(vanhasijainti, null);
		    		pelilauta.set(sijainti, MS6);
		    		MS6.asetaSijainti(tulosx1, tulosy1);
	    		}
	    	}
	    }
	    if (nappula.equals(ms7)) {
	    	int tulosx1 = Integer.parseInt(sijaintix);
	    	int tulosy1 = Integer.parseInt(sijaintiy);
	    	if (MS7.Onkosiirtosallittu(tulosx1, tulosy1)) {
	    		int sijainti = 10 * tulosx1 + tulosy1;
	    		int vanhasijainti = 10 * MS7.annaSijaintiX() + MS7.annaSijaintiY();
	    		if (pelilauta.get(sijainti) == null) {
	    			pelilauta.set(vanhasijainti, null);
	    			pelilauta.set(sijainti, MS7);
	    			MS7.asetaSijainti(tulosx1, tulosy1);
	    		}
	    		else {
		    		pelilauta.set(vanhasijainti, null);
		    		pelilauta.set(sijainti, MS7);
		    		MS7.asetaSijainti(tulosx1, tulosy1);
	    		}
	    	}
	    }
	    if (nappula.equals(ms8)) {
	    	int tulosx1 = Integer.parseInt(sijaintix);
	    	int tulosy1 = Integer.parseInt(sijaintiy);
	    	if (MS8.Onkosiirtosallittu(tulosx1, tulosy1)) {
	    		int sijainti = 10 * tulosx1 + tulosy1;
	    		int vanhasijainti = 10 * MS8.annaSijaintiX() + MS8.annaSijaintiY();
	    		if (pelilauta.get(sijainti) == null) {
	    			pelilauta.set(vanhasijainti, null);
	    			pelilauta.set(sijainti, MS8);
	    			MS8.asetaSijainti(tulosx1, tulosy1);
	    		}
	    		else {
		    		pelilauta.set(vanhasijainti, null);
		    		pelilauta.set(sijainti, MS8);
		    		MS8.asetaSijainti(tulosx1, tulosy1);
	    		}
	    	}
	    }
	    if (nappula.equals(mt1)) {
	    	int tulosx1 = Integer.parseInt(sijaintix);
	    	int tulosy1 = Integer.parseInt(sijaintiy);
	    	if (MT1.Onkosiirtosallittu(tulosx1, tulosy1)) {
	    		int sijainti = 10 * tulosx1 + tulosy1;
	    		int vanhasijainti = 10 * MT1.annaSijaintiX() + MT1.annaSijaintiY();
	    		if (pelilauta.get(sijainti) == null) {
	    			pelilauta.set(vanhasijainti, null);
	    			pelilauta.set(sijainti, MT1);
	    			MT1.asetaSijainti(tulosx1, tulosy1);
	    		}
	    		else {
		    		pelilauta.set(vanhasijainti, null);
		    		pelilauta.set(sijainti, MT1);
		    		MT1.asetaSijainti(tulosx1, tulosy1);
	    		}
	    	}
	    }
	    if (nappula.equals(mt2)) {
	    	int tulosx1 = Integer.parseInt(sijaintix);
	    	int tulosy1 = Integer.parseInt(sijaintiy);
	    	if (MT2.Onkosiirtosallittu(tulosx1, tulosy1)) {
	    		int sijainti = 10 * tulosx1 + tulosy1;
	    		int vanhasijainti = 10 * MT2.annaSijaintiX() + MT2.annaSijaintiY();
	    		if (pelilauta.get(sijainti) == null) {
	    			pelilauta.set(vanhasijainti, null);
	    			pelilauta.set(sijainti, MT2);
	    			MT2.asetaSijainti(tulosx1, tulosy1);
	    		}
	    		else {
		    		pelilauta.set(vanhasijainti, null);
		    		pelilauta.set(sijainti, MT2);
		    		MT2.asetaSijainti(tulosx1, tulosy1);
	    		}
	    	}
	    }
	    if (nappula.equals(mh2)) {
	    	int tulosx1 = Integer.parseInt(sijaintix);
	    	int tulosy1 = Integer.parseInt(sijaintiy);
	    	if (MH2.Onkosiirtosallittu(tulosx1, tulosy1)) {
	    		int sijainti = 10 * tulosx1 + tulosy1;
	    		int vanhasijainti = 10 * MH2.annaSijaintiX() + MH2.annaSijaintiY();
	    		if (pelilauta.get(sijainti) == null) {
	    			pelilauta.set(vanhasijainti, null);
	    			pelilauta.set(sijainti, MH2);
	    			MH2.asetaSijainti(tulosx1, tulosy1);
	    		}
	    		else {
		    		pelilauta.set(vanhasijainti, null);
		    		pelilauta.set(sijainti, MH2);
		    		MH2.asetaSijainti(tulosx1, tulosy1);
	    		}
	    	}
	    }
	    if (nappula.equals(mh1)) {
	    	int tulosx1 = Integer.parseInt(sijaintix);
	    	int tulosy1 = Integer.parseInt(sijaintiy);
	    	if (MH1.Onkosiirtosallittu(tulosx1, tulosy1)) {
	    		int sijainti = 10 * tulosx1 + tulosy1;
	    		int vanhasijainti = 10 * MH1.annaSijaintiX() + MH1.annaSijaintiY();
	    		if (pelilauta.get(sijainti) == null) {
	    			pelilauta.set(vanhasijainti, null);
	    			pelilauta.set(sijainti, MH1);
	    			MH1.asetaSijainti(tulosx1, tulosy1);
	    		}
	    		else {
		    		pelilauta.set(vanhasijainti, null);
		    		pelilauta.set(sijainti, MH1);
		    		MH1.asetaSijainti(tulosx1, tulosy1);
	    		}
	    	}
	    }
	    if (nappula.equals(ml1)) {
	    	int tulosx1 = Integer.parseInt(sijaintix);
	    	int tulosy1 = Integer.parseInt(sijaintiy);
	    	if (ML1.Onkosiirtosallittu(tulosx1, tulosy1)) {
	    		int sijainti = 10 * tulosx1 + tulosy1;
	    		int vanhasijainti = 10 * ML1.annaSijaintiX() + ML1.annaSijaintiY();
	    		if (pelilauta.get(sijainti) == null) {
	    			pelilauta.set(vanhasijainti, null);
	    			pelilauta.set(sijainti, ML1);
	    			ML1.asetaSijainti(tulosx1, tulosy1);
	    		}
	    		else {
		    		pelilauta.set(vanhasijainti, null);
		    		pelilauta.set(sijainti, ML1);
		    		ML1.asetaSijainti(tulosx1, tulosy1);
	    		}
	    	}
	    }
	    if (nappula.equals(ml2)) {
	    	int tulosx1 = Integer.parseInt(sijaintix);
	    	int tulosy1 = Integer.parseInt(sijaintiy);
	    	if (ML2.Onkosiirtosallittu(tulosx1, tulosy1)) {
	    		int sijainti = 10 * tulosx1 + tulosy1;
	    		int vanhasijainti = 10 * ML2.annaSijaintiX() + ML2.annaSijaintiY();
	    		if (pelilauta.get(sijainti) == null) {
	    			pelilauta.set(vanhasijainti, null);
	    			pelilauta.set(sijainti, ML2);
	    			ML2.asetaSijainti(tulosx1, tulosy1);
	    		}
	    		else {
		    		pelilauta.set(vanhasijainti, null);
		    		pelilauta.set(sijainti, ML2);
		    		ML2.asetaSijainti(tulosx1, tulosy1);
	    		}
	    	}
	    }
	    if (nappula.equals(mk)) {
	    	int tulosx1 = Integer.parseInt(sijaintix);
	    	int tulosy1 = Integer.parseInt(sijaintiy);
	    	if (MK.Onkosiirtosallittu(tulosx1, tulosy1)) {
	    		int sijainti = 10 * tulosx1 + tulosy1;
	    		int vanhasijainti = 10 * MK.annaSijaintiX() + MK.annaSijaintiY();
	    		if (pelilauta.get(sijainti) == null) {
	    			pelilauta.set(vanhasijainti, null);
	    			pelilauta.set(sijainti, MK);
	    			MK.asetaSijainti(tulosx1, tulosy1);
	    		}
	    		else {
		    		pelilauta.set(vanhasijainti, null);
		    		pelilauta.set(sijainti, MK);
		    		MK.asetaSijainti(tulosx1, tulosy1);
	    		}
	    	}
	    }
	    if (nappula.equals(mq)) {
	    	int tulosx1 = Integer.parseInt(sijaintix);
	    	int tulosy1 = Integer.parseInt(sijaintiy);
	    	if (MQ.Onkosiirtosallittu(tulosx1, tulosy1)) {
	    		int sijainti = 10 * tulosx1 + tulosy1;
	    		int vanhasijainti = 10 * MQ.annaSijaintiX() + MQ.annaSijaintiY();
	    		if (pelilauta.get(sijainti) == null) {
	    			pelilauta.set(vanhasijainti, null);
	    			pelilauta.set(sijainti, MQ);
	    			MQ.asetaSijainti(tulosx1, tulosy1);
	    		}
	    		else {
		    		pelilauta.set(vanhasijainti, null);
		    		pelilauta.set(sijainti, MQ);
		    		MQ.asetaSijainti(tulosx1, tulosy1);
	    		}
	    	}
	    }
	    if (nappula.equals(vs2)) {
	    	int tulosx1 = Integer.parseInt(sijaintix);
	    	int tulosy1 = Integer.parseInt(sijaintiy);
	    	if (VS2.Onkosiirtosallittu(tulosx1, tulosy1)) {
	    		int sijainti = 10 * tulosx1 + tulosy1;
	    		int vanhasijainti = 10 * VS2.annaSijaintiX() + VS2.annaSijaintiY();
	    		if (pelilauta.get(sijainti) == null) {
	    			pelilauta.set(vanhasijainti, null);
	    			pelilauta.set(sijainti, VS2);
	    			VS2.asetaSijainti(tulosx1, tulosy1);
	    		}
	    		else {
		    		pelilauta.set(vanhasijainti, null);
		    		pelilauta.set(sijainti, VS2);
		    		VS2.asetaSijainti(tulosx1, tulosy1);
	    		}
	    	}
	    }
	    if (nappula.equals(vs1)) {
	    	int tulosx1 = Integer.parseInt(sijaintix);
	    	int tulosy1 = Integer.parseInt(sijaintiy);
	    	if (VS1.Onkosiirtosallittu(tulosx1, tulosy1)) {
	    		int sijainti = 10 * tulosx1 + tulosy1;
	    		int vanhasijainti = 10 * VS1.annaSijaintiX() + VS1.annaSijaintiY();
	    		if (pelilauta.get(sijainti) == null) {
	    			pelilauta.set(vanhasijainti, null);
	    			pelilauta.set(sijainti, VS1);
	    			VS1.asetaSijainti(tulosx1, tulosy1);
	    		}
	    		else {
		    		pelilauta.set(vanhasijainti, null);
		    		pelilauta.set(sijainti, VS1);
		    		VS1.asetaSijainti(tulosx1, tulosy1);
	    		}
	    	}
	    }
	    if (nappula.equals(vs3)) {
	    	int tulosx1 = Integer.parseInt(sijaintix);
	    	int tulosy1 = Integer.parseInt(sijaintiy);
	    	if (VS3.Onkosiirtosallittu(tulosx1, tulosy1)) {
	    		int sijainti = 10 * tulosx1 + tulosy1;
	    		int vanhasijainti = 10 * VS3.annaSijaintiX() + VS3.annaSijaintiY();
	    		if (pelilauta.get(sijainti) == null) {
	    			pelilauta.set(vanhasijainti, null);
	    			pelilauta.set(sijainti, VS3);
	    			VS3.asetaSijainti(tulosx1, tulosy1);
	    		}
	    		else {
		    		pelilauta.set(vanhasijainti, null);
		    		pelilauta.set(sijainti, VS3);
		    		VS3.asetaSijainti(tulosx1, tulosy1);
	    		}
	    	}
	    }
	    if (nappula.equals(vs4)) {
	    	int tulosx1 = Integer.parseInt(sijaintix);
	    	int tulosy1 = Integer.parseInt(sijaintiy);
	    	if (VS4.Onkosiirtosallittu(tulosx1, tulosy1)) {
	    		int sijainti = 10 * tulosx1 + tulosy1;
	    		int vanhasijainti = 10 * VS4.annaSijaintiX() + VS4.annaSijaintiY();
	    		if (pelilauta.get(sijainti) == null) {
	    			pelilauta.set(vanhasijainti, null);
	    			pelilauta.set(sijainti, VS4);
	    			VS4.asetaSijainti(tulosx1, tulosy1);
	    		}
	    		else {
		    		pelilauta.set(vanhasijainti, null);
		    		pelilauta.set(sijainti, VS4);
		    		VS4.asetaSijainti(tulosx1, tulosy1);
	    		}
	    	}
	    }
	    if (nappula.equals(ms5)) {
	    	int tulosx1 = Integer.parseInt(sijaintix);
	    	int tulosy1 = Integer.parseInt(sijaintiy);
	    	if (VS5.Onkosiirtosallittu(tulosx1, tulosy1)) {
	    		int sijainti = 10 * tulosx1 + tulosy1;
	    		int vanhasijainti = 10 * VS5.annaSijaintiX() + VS5.annaSijaintiY();
	    		if (pelilauta.get(sijainti) == null) {
	    			pelilauta.set(vanhasijainti, null);
	    			pelilauta.set(sijainti, VS5);
	    			VS5.asetaSijainti(tulosx1, tulosy1);
	    		}
	    		else {
		    		pelilauta.set(vanhasijainti, null);
		    		pelilauta.set(sijainti, VS5);
		    		VS5.asetaSijainti(tulosx1, tulosy1);
	    		}
	    	}
	    }
	    if (nappula.equals(vs6)) {
	    	int tulosx1 = Integer.parseInt(sijaintix);
	    	int tulosy1 = Integer.parseInt(sijaintiy);
	    	if (VS6.Onkosiirtosallittu(tulosx1, tulosy1)) {
	    		int sijainti = 10 * tulosx1 + tulosy1;
	    		int vanhasijainti = 10 * VS6.annaSijaintiX() + VS6.annaSijaintiY();
	    		if (pelilauta.get(sijainti) == null) {
	    			pelilauta.set(vanhasijainti, null);
	    			pelilauta.set(sijainti, VS6);
	    			VS6.asetaSijainti(tulosx1, tulosy1);
	    		}
	    		else {
		    		pelilauta.set(vanhasijainti, null);
		    		pelilauta.set(sijainti, VS6);
		    		VS6.asetaSijainti(tulosx1, tulosy1);
	    		}
	    	}
	    }
	    if (nappula.equals(vs7)) {
	    	int tulosx1 = Integer.parseInt(sijaintix);
	    	int tulosy1 = Integer.parseInt(sijaintiy);
	    	if (VS7.Onkosiirtosallittu(tulosx1, tulosy1)) {
	    		int sijainti = 10 * tulosx1 + tulosy1;
	    		int vanhasijainti = 10 * VS7.annaSijaintiX() + VS7.annaSijaintiY();
	    		if (pelilauta.get(sijainti) == null) {
	    			pelilauta.set(vanhasijainti, null);
	    			pelilauta.set(sijainti, VS7);
	    			VS7.asetaSijainti(tulosx1, tulosy1);
	    		}
	    		else {
		    		pelilauta.set(vanhasijainti, null);
		    		pelilauta.set(sijainti, VS7);
		    		VS7.asetaSijainti(tulosx1, tulosy1);
	    		}
	    	}
	    }
	    if (nappula.equals(vs8)) {
	    	int tulosx1 = Integer.parseInt(sijaintix);
	    	int tulosy1 = Integer.parseInt(sijaintiy);
	    	if (MS8.Onkosiirtosallittu(tulosx1, tulosy1)) {
	    		int sijainti = 10 * tulosx1 + tulosy1;
	    		int vanhasijainti = 10 * MS8.annaSijaintiX() + MS8.annaSijaintiY();
	    		if (pelilauta.get(sijainti) == null) {
	    			pelilauta.set(vanhasijainti, null);
	    			pelilauta.set(sijainti, VS8);
	    			VS8.asetaSijainti(tulosx1, tulosy1);
	    		}
	    		else {
		    		pelilauta.set(vanhasijainti, null);
		    		pelilauta.set(sijainti, VS8);
		    		VS8.asetaSijainti(tulosx1, tulosy1);
	    		}
	    	}
	    }

	    if (nappula.equals(vl1)) {
	    	int tulosx1 = Integer.parseInt(sijaintix);
	    	int tulosy1 = Integer.parseInt(sijaintiy);
	    	if (VL1.Onkosiirtosallittu(tulosx1, tulosy1)) {
	    		int sijainti = 10 * tulosx1 + tulosy1;
	    		int vanhasijainti = 10 * VL1.annaSijaintiX() + VL1.annaSijaintiY();
	    		if (pelilauta.get(sijainti) == null) {
	    			pelilauta.set(vanhasijainti, null);
	    			pelilauta.set(sijainti, VL1);
	    			VL1.asetaSijainti(tulosx1, tulosy1);
	    		}
	    		else {
		    		pelilauta.set(vanhasijainti, null);
		    		pelilauta.set(sijainti, VL1);
		    		VL1.asetaSijainti(tulosx1, tulosy1);
	    		}
	    	}
	    }
	    if (nappula.equals(vl2)) {
	    	int tulosx1 = Integer.parseInt(sijaintix);
	    	int tulosy1 = Integer.parseInt(sijaintiy);
	    	if (VL2.Onkosiirtosallittu(tulosx1, tulosy1)) {
	    		int sijainti = 10 * tulosx1 + tulosy1;
	    		int vanhasijainti = 10 * VL2.annaSijaintiX() + VL2.annaSijaintiY();
	    		if (pelilauta.get(sijainti) == null) {
	    			pelilauta.set(vanhasijainti, null);
	    			pelilauta.set(sijainti, VL2);
	    			VL2.asetaSijainti(tulosx1, tulosy1);
	    		}
	    		else {
		    		pelilauta.set(vanhasijainti, null);
		    		pelilauta.set(sijainti, VL2);
		    		VL2.asetaSijainti(tulosx1, tulosy1);
	    		}
	    	}
	    }
	    if (nappula.equals(vk)) {
	    	int tulosx1 = Integer.parseInt(sijaintix);
	    	int tulosy1 = Integer.parseInt(sijaintiy);
	    	if (VK.Onkosiirtosallittu(tulosx1, tulosy1)) {
	    		int sijainti = 10 * tulosx1 + tulosy1;
	    		int vanhasijainti = 10 * VK.annaSijaintiX() + VK.annaSijaintiY();
	    		if (pelilauta.get(sijainti) == null) {
	    			pelilauta.set(vanhasijainti, null);
	    			pelilauta.set(sijainti, VK);
	    			VK.asetaSijainti(tulosx1, tulosy1);
	    		}
	    		else {
		    		pelilauta.set(vanhasijainti, null);
		    		pelilauta.set(sijainti, VK);
		    		VK.asetaSijainti(tulosx1, tulosy1);
	    		}
	    	}
	    }
	    if (nappula.equals(vq)) {
	    	int tulosx1 = Integer.parseInt(sijaintix);
	    	int tulosy1 = Integer.parseInt(sijaintiy);
	    	if (VQ.Onkosiirtosallittu(tulosx1, tulosy1)) {
	    		int sijainti = 10 * tulosx1 + tulosy1;
	    		int vanhasijainti = 10 * VQ.annaSijaintiX() + VQ.annaSijaintiY();
	    		if (pelilauta.get(sijainti) == null) {
	    			pelilauta.set(vanhasijainti, null);
	    			pelilauta.set(sijainti, VQ);
	    			VQ.asetaSijainti(tulosx1, tulosy1);
	    		}
	    		else {
		    		pelilauta.set(vanhasijainti, null);
		    		pelilauta.set(sijainti, VQ);
		    		VQ.asetaSijainti(tulosx1, tulosy1);
	    		}
	    	}
	    }
	    if (nappula.equals(vt1)) {
	    	int tulosx1 = Integer.parseInt(sijaintix);
	    	int tulosy1 = Integer.parseInt(sijaintiy);
	    	if (VT1.Onkosiirtosallittu(tulosx1, tulosy1)) {
	    		int sijainti = 10 * tulosx1 + tulosy1;
	    		int vanhasijainti = 10 * VT1.annaSijaintiX() + VT1.annaSijaintiY();
	    		if (pelilauta.get(sijainti) == null) {
	    			pelilauta.set(vanhasijainti, null);
	    			pelilauta.set(sijainti, VT1);
	    			VT1.asetaSijainti(tulosx1, tulosy1);
	    		}
	    		else {
		    		pelilauta.set(vanhasijainti, null);
		    		pelilauta.set(sijainti, VT1);
		    		VT1.asetaSijainti(tulosx1, tulosy1);
	    		}
	    	}
	    }
	    if (nappula.equals(vt2)) {
	    	int tulosx1 = Integer.parseInt(sijaintix);
	    	int tulosy1 = Integer.parseInt(sijaintiy);
	    	if (VT2.Onkosiirtosallittu(tulosx1, tulosy1)) {
	    		int sijainti = 10 * tulosx1 + tulosy1;
	    		int vanhasijainti = 10 * VT2.annaSijaintiX() + VT2.annaSijaintiY();
	    		if (pelilauta.get(sijainti) == null) {
	    			pelilauta.set(vanhasijainti, null);
	    			pelilauta.set(sijainti, VT2);
	    			VT2.asetaSijainti(tulosx1, tulosy1);
	    		}
	    		else {
		    		pelilauta.set(vanhasijainti, null);
		    		pelilauta.set(sijainti, VT2);
		    		VT2.asetaSijainti(tulosx1, tulosy1);
	    		}
	    	}
	    }
	    if (nappula.equals(vh2)) {
	    	int tulosx1 = Integer.parseInt(sijaintix);
	    	int tulosy1 = Integer.parseInt(sijaintiy);
	    	if (VH2.Onkosiirtosallittu(tulosx1, tulosy1)) {
	    		int sijainti = 10 * tulosx1 + tulosy1;
	    		int vanhasijainti = 10 * VH2.annaSijaintiX() + VH2.annaSijaintiY();
	    		if (pelilauta.get(sijainti) == null) {
	    			pelilauta.set(vanhasijainti, null);
	    			pelilauta.set(sijainti, VH2);
	    			VH2.asetaSijainti(tulosx1, tulosy1);
	    		}
	    		else {
		    		pelilauta.set(vanhasijainti, null);
		    		pelilauta.set(sijainti, VH2);
		    		VH2.asetaSijainti(tulosx1, tulosy1);
	    		}
	    	}
	    }
	    if (nappula.equals(vh1)) {
	    	int tulosx1 = Integer.parseInt(sijaintix);
	    	int tulosy1 = Integer.parseInt(sijaintiy);
	    	if (VH1.Onkosiirtosallittu(tulosx1, tulosy1)) {
	    		int sijainti = 10 * tulosx1 + tulosy1;
	    		int vanhasijainti = 10 * VH1.annaSijaintiX() + VH1.annaSijaintiY();
	    		if (pelilauta.get(sijainti) == null) {
	    			pelilauta.set(vanhasijainti, null);
	    			pelilauta.set(sijainti, VH1);
	    			VH1.asetaSijainti(tulosx1, tulosy1);
	    		}
	    		else {
		    		pelilauta.set(vanhasijainti, null);
		    		pelilauta.set(sijainti, VH1);
		    		VH1.asetaSijainti(tulosx1, tulosy1);
	    		}
	    	}
	    }
	 

			System.out.println("__________________________________________");
			System.out.println("|"+ pelilauta.get(18) + "|" + pelilauta.get(28) + "|" + pelilauta.get(38) + "|" + pelilauta.get(48) + "|" + pelilauta.get(58) +"|" + pelilauta.get(68) + "|" + pelilauta.get(78) + "|" + pelilauta.get(88) + "|");
			System.out.println("|"+ pelilauta.get(17) + "|" + pelilauta.get(27) + "|" + pelilauta.get(37) + "|" + pelilauta.get(47) + "|" + pelilauta.get(57) +"|" + pelilauta.get(67) + "|" + pelilauta.get(77) + "|" + pelilauta.get(87) + "|");
			System.out.println("|"+ pelilauta.get(16) + "|" + pelilauta.get(26) + "|" + pelilauta.get(36) + "|" + pelilauta.get(46) + "|" + pelilauta.get(56) +"|" + pelilauta.get(66) + "|" + pelilauta.get(76) + "|" + pelilauta.get(86) + "|");
			System.out.println("|"+ pelilauta.get(15) + "|" + pelilauta.get(25) + "|" + pelilauta.get(35) + "|" + pelilauta.get(45) + "|" + pelilauta.get(55) +"|" + pelilauta.get(65) + "|" + pelilauta.get(75) + "|" + pelilauta.get(85) + "|");
			System.out.println("|"+ pelilauta.get(14) + "|" + pelilauta.get(24) + "|" + pelilauta.get(34) + "|" + pelilauta.get(44) + "|" + pelilauta.get(54) +"|" + pelilauta.get(64) + "|" + pelilauta.get(74) + "|" + pelilauta.get(84) + "|");
			System.out.println("|"+ pelilauta.get(13) + "|" + pelilauta.get(23) + "|" + pelilauta.get(33) + "|" + pelilauta.get(43) + "|" + pelilauta.get(53) +"|" + pelilauta.get(63) + "|" + pelilauta.get(73) + "|" + pelilauta.get(83) + "|");
			System.out.println("|"+ pelilauta.get(12) + "|" + pelilauta.get(22) + "|" + pelilauta.get(32) + "|" + pelilauta.get(42) + "|" + pelilauta.get(52) +"|" + pelilauta.get(62) + "|" + pelilauta.get(72) + "|" + pelilauta.get(82) + "|");
			System.out.println("|"+ pelilauta.get(11) + "|" + pelilauta.get(21) + "|" + pelilauta.get(31) + "|" + pelilauta.get(41) + "|" + pelilauta.get(51) +"|" + pelilauta.get(61) + "|" + pelilauta.get(71) + "|" + pelilauta.get(81) + "|");
			System.out.println("_________________________________________");
	  }
  }
}