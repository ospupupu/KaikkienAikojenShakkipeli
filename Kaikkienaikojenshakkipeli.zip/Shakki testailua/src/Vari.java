
public enum Vari {

}
