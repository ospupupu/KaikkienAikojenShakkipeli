import java.util.ArrayList;
import java.util.List;
public class Luontialue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	ArrayList<Sotilas> myList = new ArrayList<Sotilas>();
	Sotilas MS1 = new Sotilas(1, 2, 0, 1);
}
