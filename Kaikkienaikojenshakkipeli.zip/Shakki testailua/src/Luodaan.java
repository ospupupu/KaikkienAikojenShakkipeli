
public class Luodaan {

	public void main(String[] args) {
		// TODO Auto-generated method stub

	}
	Sotilas MS1 = new Sotilas(1, 2, 0, 1);
	Sotilas MS2 = new Sotilas(2, 2, 0, 1);
	Sotilas MS3 = new Sotilas(3, 2, 0, 1);
	Sotilas MS4 = new Sotilas(4, 2, 0, 1);
	Sotilas MS5 = new Sotilas(5, 2, 0, 1);
	Sotilas MS6 = new Sotilas(6, 2, 0, 1);
	Sotilas MS7 = new Sotilas(7, 2, 0, 1);
	Sotilas MS8 = new Sotilas(8, 2, 0, 1);
	

}
