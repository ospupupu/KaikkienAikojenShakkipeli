
public class Pelikortti {

}
